"""
Expose version
"""

__version__ = "3.3.0"
VERSION = __version__.split(".")
